//src/Cnghown-service/chat-zalo/chat-special/send-sticker/send-sticker.js
import axios from "axios";
import fs from "fs/promises"; // Sử dụng fs.promises
import path from "path";
import ffmpeg from "fluent-ffmpeg";
import { getGlobalPrefix } from "../../../service.js";

// Đảm bảo fluent-ffmpeg tìm thấy ffmpeg
ffmpeg.setFfmpegPath("ffmpeg");
import {
  checkExstentionFileRemote,
  deleteFile,
  downloadFile,
  execAsync,
} from "../../../../utils/util.js";
import { MessageMention, MessageType } from "../../../../api-zalo/index.js";
import { tempDir } from "../../../../utils/io-json.js";
import { removeMention } from "../../../../utils/format-util.js";
import { getVideoMetadata } from "../../../../api-zalo/utils.js";
import { isAdmin } from "../../../../index.js";
import { appContext } from "../../../../api-zalo/context.js";

const REMOVE_BG_API_URL = "https://nqduan.id.vn/api/removebg";

/**
 * Kiểm tra URL có phải là media hợp lệ Không
 */
async function isValidMediaUrl(url) {
  try {
    const ext = await checkExstentionFileRemote(url);
    if (!ext) {
      return { isValid: false, isVideo: false };
    }
    const videoExts = ["mp4", "mov", "webm"];
    const imageExts = ["png", "jpg", "jpeg", "gif", "jxl", "webp"];
    if (videoExts.includes(ext)) return { isValid: true, isVideo: true };
    if (imageExts.includes(ext)) return { isValid: true, isVideo: false };
    return { isValid: false, isVideo: false };
  } catch (error) {
    console.error("Lỗi khi kiểm tra URL:", error.message);
    return { isValid: false, isVideo: false };
  }
}

/**
 * Kiểm tra ffmpeg có sẵn
 */
function isJxlLikeUrl(url) {
  try {
    const parsed = new URL(url);
    return (
      parsed.pathname.toLowerCase().includes("/jxl/") ||
      parsed.pathname.toLowerCase().endsWith(".jxl") ||
      parsed.searchParams.has("jxlstatus")
    );
  } catch {
    return String(url || "").toLowerCase().includes(".jxl");
  }
}

function createJpgFallbackUrl(url) {
  try {
    const parsed = new URL(url);
    const original = parsed.toString();
    parsed.pathname = parsed.pathname
      .replace(/\/jxl\//gi, "/jpg/")
      .replace(/\.jxl$/i, ".jpg");
    parsed.searchParams.delete("jxlstatus");
    const fallback = parsed.toString();
    return fallback !== original ? fallback : null;
  } catch {
    const fallback = String(url || "")
      .replace(/\/jxl\//gi, "/jpg/")
      .replace(/\.jxl(?=$|[?#])/i, ".jpg")
      .replace(/[?&]jxlstatus=\d+/i, "");
    return fallback && fallback !== url ? fallback : null;
  }
}

function addMediaCandidate(candidates, url) {
  if (!url || typeof url !== "string") return;
  const rawUrl = url.replace(/\\\//g, "/");
  let decodedUrl = rawUrl;
  try {
    decodedUrl = decodeURIComponent(rawUrl);
  } catch {}

  const add = (candidate) => {
    if (candidate && !candidates.includes(candidate)) {
      candidates.push(candidate);
    }
  };

  if (isJxlLikeUrl(decodedUrl)) {
    add(createJpgFallbackUrl(decodedUrl));
  }
  add(decodedUrl);
}

function getMediaUrlCandidates(attachData) {
  const candidates = [];
  let params = null;
  if (attachData?.params) {
    try {
      params =
        typeof attachData.params === "string"
          ? JSON.parse(attachData.params)
          : attachData.params;
    } catch {}
  }

  [
    attachData?.hdUrl,
    attachData?.href,
    attachData?.oriUrl,
    attachData?.normalUrl,
    attachData?.thumbUrl,
    attachData?.rawUrl,
    params?.hd,
    params?.url,
    params?.normalUrl,
    params?.thumbUrl,
  ].forEach((url) => addMediaCandidate(candidates, url));

  return candidates;
}

function getMediaUrlCandidatesFromUrls(urls) {
  const candidates = [];
  urls.forEach((url) => addMediaCandidate(candidates, url));
  return candidates;
}

async function removeStickerBackground(imageUrl) {
  try {
    const response = await axios.get(REMOVE_BG_API_URL, {
      params: { url: imageUrl },
      responseType: "arraybuffer",
      timeout: 60000,
      validateStatus: () => true,
    });

    const contentType = String(response.headers?.["content-type"] || "");
    const data = Buffer.from(response.data || []);
    if (response.status >= 200 && response.status < 300 && contentType.includes("image/")) {
      return data;
    }

    let detail = data.toString("utf8").trim();
    try {
      const parsed = JSON.parse(detail);
      detail = parsed.error || parsed.message || detail;
    } catch {}
    throw new Error(detail || `RemoveBG API status ${response.status}`);
  } catch (error) {
    console.error("Lỗi khi gọi API xóa nền sticker:", error.message);
    return null;
  }
}

let ffmpegDecoderList = null;

async function hasFfmpegDecoder(decoderName) {
  if (!ffmpegDecoderList) {
    try {
      const { stdout, stderr } = await execAsync("ffmpeg -hide_banner -decoders");
      ffmpegDecoderList = `${stdout || ""}\n${stderr || ""}`;
    } catch {
      ffmpegDecoderList = "";
    }
  }
  return new RegExp(`\\b${decoderName}\\b`, "i").test(ffmpegDecoderList);
}

function clampNumber(value, min, max, fallback = 0) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.max(min, Math.min(max, number));
}

function buildRoundFilter(radiusPercent) {
  const pct = clampNumber(radiusPercent, 0, 50, 0);
  if (pct <= 0) return "";
  const radius = `(min(W,H)*${pct / 100})`;
  const dx = `if(lt(X,${radius}),${radius}-X,if(gt(X,W-${radius}),X-(W-${radius}),0))`;
  const dy = `if(lt(Y,${radius}),${radius}-Y,if(gt(Y,H-${radius}),Y-(H-${radius}),0))`;
  const alpha = `if(lte(pow(${dx},2)+pow(${dy},2),pow(${radius},2)),255,0)`;
  return `format=rgba,geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='${alpha}'`;
}

function escapeDrawtextValue(value) {
  return String(value || "")
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/'/g, "\\'")
    .replace(/:/g, "\\:")
    .replace(/%/g, "%%")
    .replace(/\r/g, "")
    .replace(/\n/g, "\\n");
}

function getDrawtextFontFile() {
  if (process.platform === "win32") return "C\\:/Windows/Fonts/arial.ttf";
  return "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf";
}

function buildWriteTextFilter(text) {
  const safeText = escapeDrawtextValue(text).trim();
  if (!safeText) return "";
  return [
    `drawtext=fontfile='${getDrawtextFontFile()}'`,
    `text='${safeText}'`,
    "x=(w-text_w)/2",
    "y=h-text_h-24",
    "fontsize=42",
    "fontcolor=white",
    "borderw=4",
    "bordercolor=black@0.85",
    "line_spacing=6",
  ].join(":");
}

function buildStickerFilter({
  fps = null,
  maxSize = 512,
  radiusPercent = 0,
  cropSquare = false,
  writeText = "",
} = {}) {
  const filters = [];
  if (fps) filters.push(`fps=${fps}`);
  if (cropSquare) {
    filters.push(
      `scale='if(gt(iw,ih),-1,${maxSize})':'if(gt(iw,ih),${maxSize},-1)':flags=lanczos`,
      `crop=${maxSize}:${maxSize}`,
    );
  } else {
    filters.push(
      `scale='if(gt(iw,ih),${maxSize},-1)':'if(gt(ih,iw),${maxSize},-1)':flags=lanczos`,
    );
  }
  const roundFilter = buildRoundFilter(radiusPercent);
  if (roundFilter) filters.push(roundFilter);
  const writeTextFilter = buildWriteTextFilter(writeText);
  if (writeTextFilter) filters.push(writeTextFilter);
  return filters.join(",");
}

async function spinWebp(inputPath, outputPath, options = {}) {
  const fps = options.spinFps || 30;
  const seconds = clampNumber(options.spinSeconds, 1, 30, 6);
  const quality = options.quality || 60;
  const frames = Math.max(1, fps * seconds);
  const filter = `fps=${fps},rotate=2*PI*n/${frames}:c=none`;
  const cmd = `ffmpeg -y -loop 1 -i "${inputPath}" -filter_complex "${filter}" -t ${seconds} -vcodec libwebp -loop 0 -preset default -q:v ${quality} -an "${outputPath}"`;
  await execAsync(cmd);
}

function extractUrls(text) {
  return (text.match(/https?:\/\/[^\s"'<>]+/gi) || []).map((url) =>
    url.replace(/[),.]+$/g, ""),
  );
}

function parseStickerOptions(content) {
  const contentWithoutUrls = String(content || "").replace(/https?:\/\/[^\s"'<>]+/gi, " ");
  const tokens = contentWithoutUrls.split(/\s+/).filter(Boolean);
  const options = {
    ai: false,
    xp: false,
    spin: false,
    spinSeconds: 6,
    cropSquare: false,
    radiusPercent: 0,
    writeText: "",
  };

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i].toLowerCase();
    if (["ai", "zai", "z-ai"].includes(token)) options.ai = true;
    if (["xp", "xphong", "xoaphong", "nbg"].includes(token)) options.xp = true;
    if (token === "cat") options.cropSquare = true;

    if (token === "write") {
      options.writeText = tokens.slice(i + 1).join(" ").trim();
      break;
    }

    const spinMatch = token.match(/^(?:sd|spin)(?:[|=(]?(\d{1,2})\)?)?$/);
    if (spinMatch) {
      options.spin = true;
      if (spinMatch[1]) {
        options.spinSeconds = clampNumber(spinMatch[1], 1, 30, 6);
      } else if (tokens[i + 1] && /^\d{1,2}$/.test(tokens[i + 1])) {
        options.spinSeconds = clampNumber(tokens[i + 1], 1, 30, 6);
        i++;
      }
    }

    let radiusMatch = token.match(/^-r(?:=)?(\d{1,3})%?$/);
    if (!radiusMatch) radiusMatch = token.match(/^-r\((\d{1,3})%?\)$/);
    if (!radiusMatch && token === "-r" && tokens[i + 1]) {
      radiusMatch = String(tokens[i + 1]).match(/^(\d{1,3})%?$/);
      if (radiusMatch) i++;
    }
    if (radiusMatch) {
      options.radiusPercent = clampNumber(radiusMatch[1], 0, 50, 0);
    }
  }

  if (options.spin && options.radiusPercent === 0) {
    options.radiusPercent = 50;
  }

  return options;
}

async function ensureFfmpegAvailable() {
  try {
    await execAsync("ffmpeg -version");
    return true;
  } catch (err) {
    throw new Error(
      "ffmpeg không được tìm thấy trên hệ thống. Vui lòng cài ffmpeg (Ví dụ trên Ubuntu: sudo apt update && sudo apt install -y ffmpeg)",
    );
  }
}

/**
 * Chuyển đổi ảnh hoặc video sang WebP (hỗ trợ animated WebP cho video) sử dụng ffmpeg
 * - inputPath: đường dẫn input (local)
 * - outputPath: đường dẫn output (.webp)
 * - options: { fps, maxSize, quality }
 */
export async function convertToWebp(inputPath, outputPath, options = {}) {
  const ext = path.extname(inputPath || "").toLowerCase();
  const fps = options.fps || 12;
  const maxSize = options.maxSize || 512; // kích thước tối đa (px)
  const quality = options.quality || 60; // 0-100, thấp hơn là giảm dung lượng tăng chất lượng

  const radiusPercent = clampNumber(options.radiusPercent, 0, 50, 0);
  const spin = Boolean(options.spin);
  const spinSeconds = clampNumber(options.spinSeconds, 1, 30, 6);
  const cropSquare = Boolean(options.cropSquare);
  const writeText = options.writeText || "";

  await ensureFfmpegAvailable();

  // normalize output extension
  if (!outputPath.endsWith(".webp")) {
    outputPath = outputPath + ".webp";
  }

  try {
    if (spin) {
      const baseWebp = outputPath.replace(/\.webp$/i, `.base_${Date.now()}.webp`);
      try {
        await convertToWebp(inputPath, baseWebp, {
          ...options,
          spin: false,
          radiusPercent: radiusPercent || 50,
          spinSeconds,
          cropSquare: true,
          writeText,
        });
        await spinWebp(baseWebp, outputPath, options);
      } finally {
        await deleteFile(baseWebp);
      }
      return outputPath;
    }

    if (ext === ".jxl" && !(await hasFfmpegDecoder("jpegxl"))) {
      throw new Error(
        "File .jxl can bo giai ma JPEG XL. Bot da thu URL .jpg thay the neu co, nhung file hien tai van la .jxl. Hay cai FFmpeg co libjxl/jpegxl decoder hoac gui anh JPG/PNG/WebP.",
      );
    }

    if ([".mp4", ".mov", ".webm"].includes(ext)) {
      // Video -> animated webp
      // - fps: frame rate
      // - scale: giữ tỉ lệ, giới hạn chiều lớn nhất = maxSize
      // - loop 0: lặp vô hạn
      // - vcodec libwebp: encode to webp
      // Một command tương đối tương thích:
      const vf = buildStickerFilter({
        fps,
        maxSize,
        radiusPercent,
        cropSquare,
        writeText,
      });
      const cmd = `ffmpeg -y -i "${inputPath}" -vf "${vf}" -vcodec libwebp -loop 0 -preset default -q:v ${quality} "${outputPath}"`;
      await execAsync(cmd);
    } else if (
      // === SỬA ĐỔI TẠI ĐÂY ===
      // Đã thêm '.jxl' vào danh sách hỗ trợ
      [".png", ".jpg", ".jpeg", ".gif", ".webp", ".jxl"].includes(ext)
    ) {
      // Ảnh tĩnh or GIF -> WebP (tĩnh hoặc animated nếu là GIF có nhiều frame)
      // Dùng libwebp để tạo webp. GIF với nhiều frame sẽ trở thành animated webp.
      const vf = buildStickerFilter({
        maxSize,
        radiusPercent,
        cropSquare,
        writeText,
      });
      const cmd = `ffmpeg -y -i "${inputPath}" -vf "${vf}" -vcodec libwebp -preset default -q:v ${quality} "${outputPath}"`;
      await execAsync(cmd);
    } else {
      throw new Error(`Định dạng file không được hỗ trợ: ${ext}`);
    }
    return outputPath;
  } catch (err) {
    console.error("Lỗi khi convert sang webp:", err.message);
    throw new Error(`Lỗi khi chuyển đổi sang WebP: ${err.message}`);
  }
}

/**
 * Xử lý tạo và gửi sticker từ URL hoặc local path
 */
async function processAndSendSticker(api, message, mediaSource, stickerOptions = {}) {
  const senderName = message.data.dName || "Người dùng";
  const senderId = message.data.uidFrom;
  let pathSticker = path.join(tempDir, `sticker_${Date.now()}.templink`);
  let pathWebp = path.join(tempDir, `sticker_${Date.now()}.webp`);
  let isLocalFile = false;

  if (Array.isArray(mediaSource)) {
    let lastError = null;
    for (const candidate of mediaSource) {
      try {
        return await processAndSendSticker(api, message, candidate, stickerOptions);
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("Khong tai duoc media de tao sticker.");
  }

  try {
    // Kiểm tra nếu mediaSource là file cục bộ
    try {
      if (Array.isArray(mediaSource)) throw new Error("remote candidates");
      await fs.access(mediaSource);
      isLocalFile = true;
    } catch {
      isLocalFile = false;
    }

    let ext = null;

    if (!isLocalFile) {
      ext = await checkExstentionFileRemote(mediaSource);
      if (!ext) throw new Error("Không xác định được định dạng file.");
      pathSticker = path.join(tempDir, `sticker_${Date.now()}.${ext}`);
      await downloadFile(mediaSource, pathSticker);
    } else {
      // Nếu là file local, lấy đuôi từ tên file
      ext = path.extname(mediaSource).replace(".", "").toLowerCase();
      pathSticker = mediaSource;
    }

    const isVideo = ["mp4", "mov", "webm"].includes(ext);

    // Chuyển đổi sang webp (hỗ trợ cả video và ảnh)
    await convertToWebp(pathSticker, pathWebp, {
      fps: 12,
      maxSize: 512,
      quality: 60,
      radiusPercent: stickerOptions.radiusPercent || 0,
      spin: Boolean(stickerOptions.spin),
      spinSeconds: stickerOptions.spinSeconds || 6,
      cropSquare: Boolean(stickerOptions.cropSquare),
      writeText: stickerOptions.writeText || "",
    });

    // Upload file webp lên Zalo
    const linkUploadZalo = await api.uploadAttachment(
      [pathWebp],
      appContext.send2meId,
      MessageType.DirectMessage,
    );
    if (!linkUploadZalo || !linkUploadZalo[0])
      throw new Error(
        "Upload lên Zalo bị lỗi hoặc trả về dữ liệu không hợp lệ",
      );

    // Lấy metadata (dùng metadata từ file nguồn để có kích thước chính xác)
    let stickerData = { width: 512, height: 512 };
    try {
      stickerData = await getVideoMetadata(pathWebp);
      if (!stickerData || !stickerData.width || !stickerData.height) {
        stickerData = { width: 512, height: 512 };
      }
    } catch (err) {
      console.warn(
        "Không lấy được metadata, dùng mặc định 512x512:",
        err.message,
      );
    }

    if (stickerOptions.spin || stickerOptions.cropSquare) {
      stickerData = { ...stickerData, width: 512, height: 512 };
    }

    const uploadInfo = linkUploadZalo[0];
    const finalUrl =
      uploadInfo.fileUrl || uploadInfo.normalUrl || uploadInfo.url || "";
    if (!finalUrl) throw new Error("Không lấy được URL sticker từ Zalo");

    // Thêm đuôi creator signature vào URL (an toàn, không ảnh hưởng hiển thị)
    let stickerUrlWithSignature = finalUrl;
    try {
      const creatorTag = encodeURIComponent("khoi.Cnghown");
      const separator = finalUrl.includes("?") ? "&" : "?";
      stickerUrlWithSignature = `${finalUrl}${separator}stickerCreatedBy=${creatorTag}`;
    } catch (err) {
      console.warn(
        "[Sticker] Không thêm được signature, dùng URL gốc:",
        err.message,
      );
    }

    // Gửi tin nhắn thông báos
    await api.sendMessage(
      {
        msg: `@${senderName} Sticker của bạn đây!`,
        quote: message,
        mentions: [MessageMention(senderId, senderName.length + 1, 0)],
        ttl: 300000,
      },
      message.threadId,
      message.type,
    );

    // Gửi sticker (custom)
    await api.sendCustomSticker(
      message,
      stickerUrlWithSignature,
      stickerUrlWithSignature,
      stickerData.width,
      stickerData.height,
      3600000,
      Boolean(stickerOptions.ai),
    );

    return { success: true, pathSticker, pathWebp };
  } catch (error) {
    console.error("Lỗi khi xử lý sticker:", error.message);
    throw error;
  } finally {
    // Xóa file tạm, sử dụng deleteFile an toàn
    try {
      if (pathSticker && pathSticker !== mediaSource)
        await deleteFile(pathSticker);
    } catch (err) {
      console.warn("Không xóa được file sticker tạm:", err.message);
    }
    try {
      if (pathWebp) await deleteFile(pathWebp);
    } catch (err) {
      console.warn("Không xóa được file webp tạm:", err.message);
    }
  }
}

/**
 * Xử lý lệnh tạo sticker
 */
export async function handleStickerCommand(api, message) {
  const quote = message.data.quote;
  const senderName = message.data.dName || "Người dùng";
  const senderId = message.data.uidFrom;
  const threadId = message.threadId;
  const isAdminLevelHighest = isAdmin(senderId);
  const isAdminBot = isAdmin(senderId, threadId);
  const content = removeMention(message);
  const stickerOptions = parseStickerOptions(content);
  const directUrls = extractUrls(content);
  const prefix = getGlobalPrefix();
  const tempPath = path.join(tempDir, `sticker_${Date.now()}.png`);
  const usageText =
    `@${senderName}, Hãy reply vào tin nhắn chứa ảnh hoặc video hoặc cung cấp link content hợp lệ để tạo sticker.\n` +
    `Đối số đặc biệt:\n` +
    `xp: Xóa Phông\n` +
    `-r(%): Bo cong sticker (Max 50%)\n` +
    `sd|(n): Tạo sticker xoay tròn (n giây/vòng)\n` +
    `cat: Crop ảnh 512x512 (chỉ hỗ trợ ảnh)\n` +
    `zAI: Sticker AI\n` +
    `write <text>: Viết chữ lên sticker\n` +
    `Ví dụ: ${prefix}stk https://... -r30 sd|5 cat zAI write hello`;
  let tempPathCreated = false; // Theo dõi xem tempPath đã được tạo chưa

  // Tạo thư mục tempDir nếu chưa tồn tại
  try {
    await fs.mkdir(tempDir, { recursive: true });
  } catch (error) {
    console.error("Lỗi khi tạo thư mục tempDir:", error.message);
    await api.sendMessage(
      {
        msg: `@${senderName}, Lỗi khi tạo thư mục tạm: ${error.message}`,
        quote: message,
        mentions: [MessageMention(senderId, senderName.length + 1, 0)],
        ttl: 30000,
      },
      threadId,
      message.type,
    );
    return;
  }

  if (!quote && directUrls.length === 0) {
    await api.sendMessage(
      {
        msg: usageText,
        quote: message,
        mentions: [MessageMention(senderId, senderName.length + 1, 0)],
        ttl: 30000,
      },
      threadId,
      message.type,
    );
    return;
  }

  const attach = quote?.attach;
  if (directUrls.length === 0 && !attach) {
    await api.sendMessage(
      {
        msg: `@${senderName}, Không có đính kèm nào trong nội dung reply của bạn.`,
        quote: message,
        mentions: [MessageMention(senderId, senderName.length + 1, 0)],
        ttl: 30000,
      },
      threadId,
      message.type,
    );
    return;
  }

  try {
    const attachData = attach ? JSON.parse(attach) : null;
    const mediaUrlCandidates =
      directUrls.length > 0
        ? getMediaUrlCandidatesFromUrls(directUrls)
        : getMediaUrlCandidates(attachData);

    if (mediaUrlCandidates.length === 0) {
      await api.sendMessage(
        {
          msg: `@${senderName}, Không tìm thấy URL trong đính kèm của tin nhắn bạn đã reply.`,
          quote: message,
          mentions: [MessageMention(senderId, senderName.length + 1, 0)],
          ttl: 30000,
        },
        threadId,
        message.type,
      );
      return;
    }

    let mediaCheck = null;
    let selectedMediaUrl = null;
    for (const candidate of mediaUrlCandidates) {
      const candidateCheck = await isValidMediaUrl(candidate);
      if (candidateCheck.isValid) {
        mediaCheck = candidateCheck;
        selectedMediaUrl = candidate;
        break;
      }
    }
    const decodedUrl = selectedMediaUrl;
    if (!mediaCheck || !selectedMediaUrl) {
      console.error("URL Không hợp lệ:", decodedUrl);
      await api.sendMessage(
        {
          msg: `@${senderName}, URL trong tin nhắn bạn reply Không phải là ảnh, GIF hoặc video hợp lệ.`,
          quote: message,
          mentions: [MessageMention(senderId, senderName.length + 1, 0)],
          ttl: 30000,
        },
        threadId,
        message.type,
      );
      return;
    }

    const isVideo = mediaCheck.isVideo;
    const isXoaPhong = stickerOptions.xp;

    if (isXoaPhong && isVideo) {
      await api.sendMessage(
        {
          msg: `@${senderName} Chưa hỗ trợ xóa phông cho sticker video!`,
          quote: message,
          mentions: [MessageMention(senderId, senderName.length + 1, 0)],
          ttl: 6000,
        },
        threadId,
        message.type,
      );
      return;
    }

    if (stickerOptions.cropSquare && isVideo) {
      await api.sendMessage(
        {
          msg: `@${senderName} cat chỉ hỗ trợ ảnh, chưa hỗ trợ sticker video!`,
          quote: message,
          mentions: [MessageMention(senderId, senderName.length + 1, 0)],
          ttl: 30000,
        },
        threadId,
        message.type,
      );
      return;
    }

    if (!isAdminBot && isVideo) {
      await api.sendMessage(
        {
          msg: `@${senderName}, Đại ca tao Không cho phép thành viên tạo sticker video.`,
          quote: message,
          mentions: [MessageMention(senderId, senderName.length + 1, 0)],
          ttl: 30000,
        },
        threadId,
        message.type,
      );
      return;
    }

    await api.sendMessage(
      {
        msg: `@${senderName} Ok, đang tạo sticker, chờ một chút!`,
        quote: message,
        mentions: [MessageMention(senderId, senderName.length + 1, 0)],
        ttl: 6000,
      },
      threadId,
      message.type,
    );

    if (isXoaPhong) {
      const imageData = await removeStickerBackground(decodedUrl);
      if (!imageData) {
        await api.sendMessage(
          {
            msg: `@${senderName}, Ựa, xóa phông lỗi hoặc hết cụ mịa ròi.`,
            quote: message,
            mentions: [MessageMention(senderId, senderName.length + 1, 0)],
            ttl: 30000,
          },
          threadId,
          message.type,
        );
        return;
      }
      await fs.writeFile(tempPath, imageData);
      tempPathCreated = true; // Đánh dấu tempPath đã được tạo
      await processAndSendSticker(api, message, tempPath, stickerOptions);
    } else {
      await processAndSendSticker(api, message, mediaUrlCandidates, stickerOptions);
    }
  } catch (error) {
    console.error("Lỗi khi xử lý lệnh sticker:", error.message);
    await api.sendMessage(
      {
        msg: `@${senderName} Lỗi Khi Xử Lý Lệnh Sticker -> ${error.message}`,
        quote: message,
        mentions: [MessageMention(senderId, senderName.length + 1, 0)],
        ttl: 30000,
      },
      threadId,
      message.type,
    );
  } finally {
    // Chỉ xóa tempPath nếu nó được tạo (trong trường hợp xóa phông)
    if (tempPathCreated) {
      await deleteFile(tempPath);
    }
  }
}
