# CngHownZL

Bot Zalo Node.js v2.1.1.

## Trang thai loi da fix

- Da doi thu muc service cu sang `Cnghown-service`.
- Da sua `speedtest-net` sang lazy import de bot khong crash vi `lzma-native` khi khoi dong.
- Da tu tao `logs/message.json` neu thieu.
- Da tao thu muc cache audio `.converted` bang `recursive: true`.

Loi `ECONNREFUSED` MySQL khong phai loi code. Can bat MySQL/XAMPP hoac MySQL service tren VPS.

## Yeu cau he thong

### Ubuntu VPS

Khuyen dung Ubuntu 22.04/24.04 va Node.js 20 LTS.

```bash
sudo apt update
sudo apt install -y git curl ca-certificates build-essential python3 make g++ pkg-config \
  libcairo2-dev libpango1.0-dev libjpeg-dev libgif-dev librsvg2-dev \
  ffmpeg mysql-server
```

Neu VPS chay Puppeteer/Chrome bi loi thieu thu vien, cai them:

```bash
sudo apt install -y libnss3 libatk-bridge2.0-0 libxkbcommon0 libxcomposite1 \
  libxdamage1 libxrandr2 libgbm1 libasound2t64 libpangocairo-1.0-0 \
  libgtk-3-0 fonts-liberation
```

Cai Node.js 20 bang nvm:

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install 20
nvm use 20
node -v
npm -v
```

### Windows

- Node.js 20.x
- Python 3.x
- Visual Studio Build Tools voi workload `Desktop development with C++`
- XAMPP MySQL neu chay local

## Cai dat tren VPS

```bash
git clone https://github.com/cnghown/CnghownZL.git
cd CnghownZL
npm ci
```

Neu `npm ci` loi do lockfile/native module, dung:

```bash
npm install
npm rebuild
```

## Cau hinh bot

Tao file dang nhap Zalo tu template:

```bash
cp assets/config.example.json assets/config.json
nano assets/config.json
```

Dien 3 thong tin:

- `cookie`: cookie export tu Zalo Web
- `imei`: IMEI/session id cua Zalo Web
- `userAgent`: user agent dung khi lay cookie

Tao file bien moi truong tuy chon:

```bash
cp .env.example .env
nano .env
```

Cac key trong `.env` khong bat buoc cho bot khoi dong. Chi dien khi muon dung cac lenh goi dich vu ngoai:

- `GEMINI_API_KEY`: chat AI, phan tich anh, tao anh.
- `TENOR_API_KEY`: lenh GIF Tenor.
- `WEATHER_API_KEY`: lenh thoi tiet.
- `SERPAPI_KEY`: lenh Google Search AI.
- `REMOVE_BG_API_KEY`: xoa nen anh.
- `HOANGDEV_XOSO_API_KEY`, `HOANGDEV_LAMNET_API_KEY`: so xo/lam net anh.
- `SPOTIFY_CLIENT_ID`, `SPOTIFY_CLIENT_SECRET`: lenh Spotify.
- `TIKTOK_COOKIE`: tuy chon, neu lenh TikTok can cookie rieng.
- `BCH_TEST_GROUP_ID`: tuy chon, ID nhom dung cho automation test rieng.

Tao file cau hinh API crawl neu can dung ZingMP3/SoundCloud:

```bash
cp src/Cnghown-service/api-crawl/config.example.json src/Cnghown-service/api-crawl/config.json
nano src/Cnghown-service/api-crawl/config.json
```

Tao file database:

```bash
cp assets/json-data/database-config.example.json assets/json-data/database-config.json
nano assets/json-data/database-config.json
```

Tao database MySQL:

```bash
sudo systemctl enable mysql
sudo systemctl start mysql
sudo mysql
```

Trong MySQL:

```sql
CREATE DATABASE IF NOT EXISTS bchbot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '';
FLUSH PRIVILEGES;
EXIT;
```

Neu VPS dat password MySQL, sua `password` trong `assets/json-data/database-config.json`.

## Chay bot

Chay truc tiep:

```bash
npm start
```

Chay bang PM2:

```bash
npm install -g pm2
pm2 start src/index.js --name cnghownzl
pm2 logs cnghownzl
pm2 save
pm2 startup
```

Web server mac dinh chay port `2000`. Neu VPS co firewall:

```bash
sudo ufw allow 2000/tcp
```

## Loi thuong gap

### Cannot find module `node-schedule`

Chua cai dependency:

```bash
npm ci
```

### Loi `canvas`, `sharp`, `diskusage`, `lzma-native`, `node-gyp`

Thieu build tools native. Tren Ubuntu cai:

```bash
sudo apt install -y build-essential python3 make g++ pkg-config libcairo2-dev libpango1.0-dev libjpeg-dev libgif-dev librsvg2-dev
npm rebuild
```

Tren Windows cai Visual Studio Build Tools voi `Desktop development with C++`.

### Lenh `sticker` loi `.jxl` / JPEG XL

Anh tu Zalo co the la JPEG XL (`.jxl`). Bot se tu thu URL `.jpg` thay the truoc. Neu van gap loi thieu decoder `jpegxl`, cai ban FFmpeg co ho tro `libjxl` hoac dung anh JPG/PNG/WebP.

### `ECONNREFUSED` MySQL

MySQL chua chay hoac sai host/user/password:

```bash
sudo systemctl start mysql
sudo systemctl status mysql
```

### Lenh `speedtest` loi `lzma-native`

Bot van khoi dong binh thuong. Rieng lenh `speedtest` can build duoc `lzma-native`, hay cai build tools va chay:

```bash
npm rebuild lzma-native
```

## Luu y Git

Khong commit cac file sau:

- `node_modules/`
- `logs/`
- `assets/temp/`
- `ads-config.json`, `ads-state.json`, `groupSettings.json`, `rao-state.json`
- `assets/config.json`
- `assets/json-data/database-config.json`
- `.env`
- `src/Cnghown-service/api-crawl/config.json`
- `src/Cnghown-service/lienquanmobile/lq.txt`
- `src/Cnghown-service/spamsms/*.py`

Moi may/VPS tu tao `assets/config.json` va `assets/json-data/database-config.json` tu file `.example.json`.
